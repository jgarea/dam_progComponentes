package com.jose.apirest.Person;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/person")
@RequiredArgsConstructor
public class PersonController {

    private final PersonService personService;
    @PostMapping("/create")
    @ResponseBody
    public Person createPerson(@RequestBody Person person){
        return personService.createPerson(person);
    }

    @DeleteMapping("/{id}")
    public void deletePerson(@PathVariable Integer id){
        personService.delete(id);
    }

    @GetMapping("/{id}")
    @ResponseBody
    public Person findById(@PathVariable Integer id){
        return personService.findById(id);
    }

    @PostMapping("/update")
    public Person updatePerson(@RequestBody Person person){
        return personService.updatePerson(person);
    }

    /**
     * Posible emprego de ResponseEntity
     *
    @PostMapping("/update")
    public ResponseEntity<Person> updatePerson(@RequestBody Person person){
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(personService.updatePerson(person));
    }
     */
}
