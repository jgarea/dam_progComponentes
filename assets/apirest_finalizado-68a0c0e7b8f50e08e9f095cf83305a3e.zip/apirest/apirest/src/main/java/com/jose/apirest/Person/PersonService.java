package com.jose.apirest.Person;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class PersonService {

    private final PersonRepository personRepository;

    public Person createPerson(Person person){
        return personRepository.save(person);
    }

    public Person findById(Integer id){
         return personRepository.findById(id).orElse(null);
    }

    public void delete(Integer id){
        personRepository.deleteById(id);
    }

    public Person updatePerson(Person person){
        return personRepository.save(person);
    }
}
