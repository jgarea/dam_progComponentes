package com.example.books;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReadingListService {

	@Autowired
	private ReadingListRepository readingListRepository;

	public List<Book> findByReader(String reader) {
		return readingListRepository.findByReader(reader);
	}

	public void save(Book book) {
		readingListRepository.save(book);
	}
}
