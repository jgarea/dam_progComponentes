package com.jose.apirest.Person;

import io.swagger.v3.oas.annotations.*;
import io.swagger.v3.oas.annotations.media.*;
import io.swagger.v3.oas.annotations.responses.*;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/person")
@RequiredArgsConstructor
public class PersonController {

    private final PersonService personService;
    @PostMapping("/create")
    @ResponseBody
    public Person createPerson(@RequestBody Person person){
        return personService.createPerson(person);
    }

    @Operation(summary = "Función de eliminación de los datos de una Persona")
    @ApiResponses(
            value = {
                    @ApiResponse(responseCode = "200", description = "Persona eliminada",
                            content = @Content)
            }
    )
    @DeleteMapping("/{id}")
    public void deletePerson(@Parameter(description = "id de la persona a eliminar") @PathVariable Integer id){
        personService.delete(id);
    }

    @GetMapping("/{id}")
    @ResponseBody
    public Person findById(@PathVariable Integer id){
        return personService.findById(id);
    }


    @Operation(summary = "Función de actualización de los datos de una Persona")

    @ApiResponses(
            value = {
                    @ApiResponse(responseCode = "200", description = "Persona encontrada y datos modificados",
                    content = {@Content(mediaType = "application/json",
                    schema = @Schema(implementation = Person.class))})
            }
    )
    @PostMapping("/update")
    public ResponseEntity<Person> updatePerson(@Valid @RequestBody Person person){
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(personService.updatePerson(person));
    }
}
